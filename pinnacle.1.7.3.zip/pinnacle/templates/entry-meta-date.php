<div class="postmeta updated color_gray">
    <div class="postdate bg-lightgray headerfont" itemprop="datePublished">
        <span class="postday"><?php echo get_the_date('j'); ?></span>
        <?php echo get_the_date('M Y');?>
    </div>       
</div>